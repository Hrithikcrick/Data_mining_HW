#!/usr/bin/env bash
set -e
python3 convert.py "$1" "$2" "$3"
