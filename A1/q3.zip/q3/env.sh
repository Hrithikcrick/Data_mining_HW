#!/usr/bin/env bash
set -e
echo "Environment ready"
