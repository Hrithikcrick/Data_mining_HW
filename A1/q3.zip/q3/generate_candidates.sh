#!/usr/bin/env bash
set -e
python3 generate_candidates.py "$1" "$2" "$3"
