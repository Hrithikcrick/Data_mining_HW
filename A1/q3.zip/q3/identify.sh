#!/usr/bin/env bash
set -e
python3 identify.py "$1" "$2"
